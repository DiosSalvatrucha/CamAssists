<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CageConfig;
use Carbon\Carbon;

class MainController extends Controller
{

    public function getCameras(){
        $Cameras = CageConfig::all();
        return view('cameras')->with(['cameras' => $Cameras]);
    }

    public function getCamera($id){
        $Camera = CageConfig::where(['idCage' => $id])->first();
        return view('edit')->with(['camera' => $Camera]);
    }



    public function saveCamera(Request $request){

        $id = $request->id;
        $finalLowUrl = $request->finalLowUrl;
        $finalHighUrl = $request->finalHighUrl;

        $Cameras = CageConfig::all();



        if($id && $finalLowUrl && $finalHighUrl){
            $Camera = CageConfig::where(['idCage' => $id])->first();
            $Camera->videoUrlLow    = $finalLowUrl;
            $Camera->videoUrlHigh   = $finalHighUrl;
            $Camera->save();

            $Cameras = CageConfig::all();

            return view('cameras')->with(['success' => ["¡Ha actualizado la camára!"], 'cameras' => $Cameras]);
        }else{
            return view('cameras')->with(['errors' => ["Hubo un error al ejecutar la consulta."], 'cameras' => $Cameras]);
        }
    }
}

?>
