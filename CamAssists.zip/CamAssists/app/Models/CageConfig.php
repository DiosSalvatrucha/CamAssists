<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CageConfig extends Model
{

    protected $table = "cageConfig";
    protected $primaryKey = 'idCage';
    public $timestamps = false;


    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'module',
        'locationX',
        'locationY',
        'videoUrlLow',
        'videoUrlHigh',
        'videoStoreUrl',
        'name',
        'description',
        'indicatorTable',
        'scalingTable',
        'visible',
        'borderWidth',
        'borderColor',
        'borderBlink',
        'videoUrlMind'
    ];

}
