<?php
$cwd='/tmp';
$descriptorspec = array(
    0 => array("pipe", "r"),
    1 => array("pipe", "w"),
    2 => array("pipe", "w"));


$process = proc_open("ffprobe rtsp://admin:admin123%@192.168.56.1:8554/streaming/channels/102", $descriptorspec, $pipes, $cwd);
$var1 = pipes
echo("pipe 1 \n");
echo stream_get_contents($pipes[1]);
echo("pipe 2 \n");
echo stream_get_contents($pipes[2]);

fclose($pipes[1]);
fclose($pipes[2]);


